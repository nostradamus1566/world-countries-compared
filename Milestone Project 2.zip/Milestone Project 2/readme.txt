Interactive Frontend development Milestone Project

This project is about comparing a selection of 8 countries to each other from a list of over 200 countries. The countries can be compared from different aspects. For example, by population or by area per square mile or by GDP per capita, etc. It is a data visualization website, showing the comparisons represented in a bar chart consisting of 8 coloured bars.

On the top row there are 8 drop-down list-boxes. Each list-box contains a big list of over 200 countries. The user can select one country from each of the 8 drop-down list-boxes. Each list-box has a different colour. The colour scheme corresponds to the colour scheme of the bars on the bar chart.
On the line below the list boxes there are 6 radio buttons with descriptive names for each button. Only one of the 6 radio buttons can be selected at a time. The radio button selected determines the type of bar chart you want to see. For example, if you select GDP radio button then you want to see 8 countries compared to each other by GDP per capita. The title of the bar chart changes depending on the radio button selected, to help the user to understand the meaning of the bar chart.

The data for the bar chart comes from the countries.csv file inside the data folder.   
The data may be over 10 or 15 years old. This is 2019. The data originally came from the website gsociology.icaap.org/data/PD_useful.xls.
The bar chart is interactive in the sense that if you select a different country or a different radio button you see the bar chart change immediately. Some JavaScript is used to achieve this interactivity.

I got some help from the internet. In particular I copied and modified some JavaScript code written by Curran Kelleher from the website at https://bl.ocks.org/curran/fea34ca9b3b8886e3ab8 in order to render the 8 coloured bars and have the titles at the bottom of chart at a slanted angle near each bar.

Michael Finnegan, Saturday 6th July 2019
Developed at Kerry ETB, Tralee. Ireland.


