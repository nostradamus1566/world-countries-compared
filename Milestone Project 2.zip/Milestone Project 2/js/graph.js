queue()
    .defer(d3.csv, "data/countries.csv")
    .await(makeGraphs);
    
function makeGraphs(error, salaryData) {
    var ndx = crossfilter(salaryData);
    /*
    salaryData.forEach(function(d){
        d.salary = parseInt(d.salary);
    */
	var toolbox = new Toolbox("data/countries.cvs");
	toolbox.readCSVFile();

	}
    
    //show_discipline_selector(ndx);
   // show_gender_balance(ndx);
   // show_average_salary(ndx);
   // show_rank_distribution(ndx);
    
    //dc.renderAll();
//}
/*
function show_discipline_selector(ndx) {
    var dim = ndx.dimension(dc.pluck('country'));
    var group = dim.group();
    
	/*
    dc.selectMenu("#discipline-selector")
        .dimension(dim)
        .group(group);
	*/
//}




